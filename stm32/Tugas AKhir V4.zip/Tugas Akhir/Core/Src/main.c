/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <stdbool.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
CRC_HandleTypeDef hcrc;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;
TIM_HandleTypeDef htim5;

UART_HandleTypeDef huart4;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_UART4_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM4_Init(void);
static void MX_CRC_Init(void);
static void MX_TIM5_Init(void);
static void MX_TIM1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
double cumError, rateError;
double mapCalc;
unsigned long currentTime, previousTime;
double elapsedTime;
double error;
double lastError;
float ICValue1;
float Duty1;
uint32_t Frequency1;
float ICValue2;
float Duty2;
uint32_t Frequency2;
int Angle1;
int Angle2;
int PRLX2_Degree_0 = 180;

//Stepper pos
float pos0 = 0;

//PID Paramater
double Kp = 1;
double Ki = 0;
double Kd = 0;

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{

	if(htim->Instance == TIM2){
		if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1){  // If the interrupt is triggered by channel 1
			// Read the IC value
			ICValue2 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);
			if (ICValue2 != 0){
				// calculate the Duty Cycle
				Duty2 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_2)/ICValue2;
				Frequency2 = 84000000/1000/ICValue2;
				Angle2 = (Duty2-0.029)*359/(0.971-0.029);
				if (Angle2 > 360)
					Angle2 = 360;
				if (Angle2 < 0)
					Angle2 = 0;
				//COMPUTE_PID_Parallax_2(double setPoint);
			}
		}
	}

	if(htim->Instance == TIM3){
		if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1){  // If the interrupt is triggered by channel 1
			// Read the IC value
			ICValue1 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);
			if (ICValue1 != 0){
				// calculate the Duty Cycle
				Duty1 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_2)/ICValue1;
				Frequency1 = 84000000/1000/ICValue1;
				Angle1 = (Duty1-0.029)*359/(0.971-0.029);
				if (Angle1 > 360)
					Angle1 = 360;
				if (Angle1 < 0)
					Angle1 = 0;
				//COMPUTE_PID_Parallax_1(double setPoint);
			}
		}
	}

}

void KST2(int derajat){
	uint32_t TIMER_Calculation=(derajat-0)*(4462-9324)/(180-0)+9324;
	TIM5->CCR4=TIMER_Calculation;
}

void KST1(int derajat){
	uint32_t TIMER_Calculation=(derajat-0)*(4462-9324)/(180-0)+9324;
	TIM5->CCR1=TIMER_Calculation;
}
void HAL_Delay_us(uint16_t delay){
	__HAL_TIM_SET_COUNTER(&htim1,0);  // set the counter value a 0
	while (__HAL_TIM_GET_COUNTER(&htim1) < delay);
}

void STEPPER_CONTROL(bool Direction, int Rev){
	if (Direction==true){//CW
		HAL_GPIO_WritePin(GPIOF, GPIO_PIN_10, GPIO_PIN_SET); //Go up
	}
	else if (Direction==false){//CCW
		HAL_GPIO_WritePin(GPIOF, GPIO_PIN_10, GPIO_PIN_RESET); //Go down
	}
  	for (int i=0; i<Rev; i++){
  		HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9, GPIO_PIN_SET);
  		HAL_Delay_us(500);
  		HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9, GPIO_PIN_RESET);
  		HAL_Delay_us(500);
  		bool LSA = HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_4);
  		bool LSB = HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_3);
  		if(LSA != 1){ //LSA Active
  			HAL_GPIO_WritePin(GPIOF, GPIO_PIN_10, GPIO_PIN_RESET); //Go down
  			i = 0;
  			Rev = 400;
  		}
  		if (LSB != 1){ //LSB Active
  			HAL_GPIO_WritePin(GPIOF, GPIO_PIN_10, GPIO_PIN_SET); //Go Up
 			i = 0;
			Rev = 400;
  		}
	}

}

void STEPPER_POS(float pos){
	// Pos from 14.37 to 188.16 (26.37 to 176.16)
	// Assuming prismatic joint already hit LSA

	float dis = pos - pos0;

	if (dis > 0){//CW
		HAL_GPIO_WritePin(GPIOF, GPIO_PIN_10, GPIO_PIN_SET); //Go up
	}
	else if (dis <= 0){//CCW
		HAL_GPIO_WritePin(GPIOF, GPIO_PIN_10, GPIO_PIN_RESET); //Go down
		dis = dis * -1;
	}

	float rev_float = dis * 1600/8;
	int rev_int = rev_float;
	float value = rev_float - rev_int;

	// Round rev value
	if (value >= 0.5){
		rev_int = rev_int + 1;
	}

  	for (int i=0; i<rev_int; i++){
  		HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9, GPIO_PIN_SET);
  		HAL_Delay_us(500);
  		HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9, GPIO_PIN_RESET);
  		HAL_Delay_us(500);
  		bool LSA = HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_4);
  		bool LSB = HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_3);
  		if(LSA != 1){ //LSA Active
  			HAL_GPIO_WritePin(GPIOF, GPIO_PIN_10, GPIO_PIN_RESET); //Go down
  			i = 0;
  			rev_int = 400;
  		}
  		if (LSB != 1){ //LSB Active
  			HAL_GPIO_WritePin(GPIOF, GPIO_PIN_10, GPIO_PIN_SET); //Go Up
 			i = 0;
			rev_int = 400;
  		}
	}

  	// Update posisiton
  	pos0 = pos;

}

uint32_t microsISR()
{
    uint32_t ms;
    uint32_t st;

    // Read UptimeMillis and SysTick->VAL until
    // UptimeMillis doesn't rollover.
    do
    {
        ms = HAL_GetTick();
        st = SysTick->VAL;
    } while (ms != HAL_GetTick());

    return ms * 1000 - st / ((SysTick->LOAD + 1) / 1000);
}

int _write(int file, char *ptr, int len){
	int i=0;
	for(i=0; i<len; i++){
		ITM_SendChar((*ptr++));
	}
	return len;
}

void PRLX1(int degree1, int threshold1)
{
    float output, offset, value;
    for (int errorAngle1 = degree1 - Angle1;
         abs(errorAngle1) > threshold1;
         errorAngle1 = degree1 - Angle1)
    {
    	if (ICValue1 < 100){
			output = errorAngle1 * Kp;
			if (output > 200.0)
				output = 200.0;
			if (output < -200.0)
				output = -200.0;
			if (errorAngle1 > 0)
				offset = 30.0;
			else if (errorAngle1 < 0)
				offset = -30.0;
			else
				offset = 0.0;

			value = output + offset;
    	}
    	else{
    		value = 0;
    	}

        TIM4->CCR1=1490-value;
    }
    TIM4->CCR1=1490;
}

void PRLX2(int degree2, int threshold2)
{
    float output, offset, value;
    for (int errorAngle2 = degree2 - Angle2;
         abs(errorAngle2) > threshold2;
         errorAngle2 = degree2 - Angle2)
    {
    	if (ICValue2 < 100){
			output = errorAngle2 * Kp;
			if (output > 200.0)
				output = 200.0;
			if (output < -200.0)
				output = -200.0;
			if (errorAngle2 > 0)
				offset = 30.0;
			else if (errorAngle2 < 0)
				offset = -30.0;
			else
				offset = 0.0;

			value = output + offset;
    	}
    	else{
			value = 0;
		}

        TIM4->CCR2=1490-value;
    }
    TIM4->CCR2=1490;
}

void Gripper(int roll, int pitch, int yaw, int jaw)
// Default 	: Gripper(180, 180, 180, 0)
// Range	: roll = 45-315; pitch = 90-270; yaw = 90-270; jaw = 0-20
{
	// roll
	if (roll == 315)
		KST2(179);
	else
	KST2((roll-45)*180/270);

	// pitch
	KST1(pitch-90);

	// yaw & jaw
	int PRLX1_Degree = yaw + (pitch-180)*45/90 - jaw/2;
	int PRLX2_Degree = yaw + (pitch-180)*45/90 + jaw/2;
	//PRLX2 Rotate First
	//1330 1490 1650 for 290 diff degree
	//1450 1490 1530 for 10 diff degree

	if(PRLX2_Degree - PRLX2_Degree_0 < 0)
		TIM4->CCR2 = 1490 - ((PRLX2_Degree-PRLX2_Degree_0 + 10) * 50/80 - 40);
	if(PRLX2_Degree - PRLX2_Degree_0 == 0)
		TIM4->CCR2 = 1490;
	if(PRLX2_Degree - PRLX2_Degree_0 > 0)
		TIM4->CCR2 = 1490 - ((PRLX2_Degree-PRLX2_Degree_0 - 10) * 50/80 + 40);

	PRLX1(PRLX1_Degree, 3);
	PRLX2(PRLX2_Degree, 3);

	PRLX2_Degree_0 = PRLX2_Degree;
//	if (pitch == 180){
//		PRLX1(yaw - jaw/2, 3);
//		PRLX2(yaw + jaw/2, 3);
//	}
//	if (pitch < 180){
//		PRLX1(yaw - (180-pitch)*45/90 - jaw/2, 3);
//		PRLX2(yaw - (180-pitch)*45/90 + jaw/2, 3);
//	}
//	if (pitch > 180){
//		PRLX1(yaw + (pitch-180)*45/90 - jaw/2, 3);
//		PRLX2(yaw + (pitch-180)*45/90 + jaw/2, 3);
//	}
}

unsigned short update_crc(unsigned short crc_accum, unsigned char *data_blk_ptr,
                          unsigned short data_blk_size)
{
  unsigned short i, j;
  unsigned short crc_table[256] = {0x0000, 0x8005, 0x800F, 0x000A, 0x801B,
                                   0x001E, 0x0014, 0x8011, 0x8033, 0x0036, 0x003C, 0x8039, 0x0028,
                                   0x802D, 0x8027, 0x0022, 0x8063, 0x0066, 0x006C, 0x8069, 0x0078,
                                   0x807D, 0x8077, 0x0072, 0x0050, 0x8055, 0x805F, 0x005A, 0x804B,
                                   0x004E, 0x0044, 0x8041, 0x80C3, 0x00C6, 0x00CC, 0x80C9, 0x00D8,
                                   0x80DD, 0x80D7, 0x00D2, 0x00F0, 0x80F5, 0x80FF, 0x00FA, 0x80EB,
                                   0x00EE, 0x00E4, 0x80E1, 0x00A0, 0x80A5, 0x80AF, 0x00AA, 0x80BB,
                                   0x00BE, 0x00B4, 0x80B1, 0x8093, 0x0096, 0x009C, 0x8099, 0x0088,
                                   0x808D, 0x8087, 0x0082, 0x8183, 0x0186, 0x018C, 0x8189, 0x0198,
                                   0x819D, 0x8197, 0x0192, 0x01B0, 0x81B5, 0x81BF, 0x01BA, 0x81AB,
                                   0x01AE, 0x01A4, 0x81A1, 0x01E0, 0x81E5, 0x81EF, 0x01EA, 0x81FB,
                                   0x01FE, 0x01F4, 0x81F1, 0x81D3, 0x01D6, 0x01DC, 0x81D9, 0x01C8,
                                   0x81CD, 0x81C7, 0x01C2, 0x0140, 0x8145, 0x814F, 0x014A, 0x815B,
                                   0x015E, 0x0154, 0x8151, 0x8173, 0x0176, 0x017C, 0x8179, 0x0168,
                                   0x816D, 0x8167, 0x0162, 0x8123, 0x0126, 0x012C, 0x8129, 0x0138,
                                   0x813D, 0x8137, 0x0132, 0x0110, 0x8115, 0x811F, 0x011A, 0x810B,
                                   0x010E, 0x0104, 0x8101, 0x8303, 0x0306, 0x030C, 0x8309, 0x0318,
                                   0x831D, 0x8317, 0x0312, 0x0330, 0x8335, 0x833F, 0x033A, 0x832B,
                                   0x032E, 0x0324, 0x8321, 0x0360, 0x8365, 0x836F, 0x036A, 0x837B,
                                   0x037E, 0x0374, 0x8371, 0x8353, 0x0356, 0x035C, 0x8359, 0x0348,
                                   0x834D, 0x8347, 0x0342, 0x03C0, 0x83C5, 0x83CF, 0x03CA, 0x83DB,
                                   0x03DE, 0x03D4, 0x83D1, 0x83F3, 0x03F6, 0x03FC, 0x83F9, 0x03E8,
                                   0x83ED, 0x83E7, 0x03E2, 0x83A3, 0x03A6, 0x03AC, 0x83A9, 0x03B8,
                                   0x83BD, 0x83B7, 0x03B2, 0x0390, 0x8395, 0x839F, 0x039A, 0x838B,
                                   0x038E, 0x0384, 0x8381, 0x0280, 0x8285, 0x828F, 0x028A, 0x829B,
                                   0x029E, 0x0294, 0x8291, 0x82B3, 0x02B6, 0x02BC, 0x82B9, 0x02A8,
                                   0x82AD, 0x82A7, 0x02A2, 0x82E3, 0x02E6, 0x02EC, 0x82E9, 0x02F8,
                                   0x82FD, 0x82F7, 0x02F2, 0x02D0, 0x82D5, 0x82DF, 0x02DA, 0x82CB,
                                   0x02CE, 0x02C4, 0x82C1, 0x8243, 0x0246, 0x024C, 0x8249, 0x0258,
                                   0x825D, 0x8257, 0x0252, 0x0270, 0x8275, 0x827F, 0x027A, 0x826B,
                                   0x026E, 0x0264, 0x8261, 0x0220, 0x8225, 0x822F, 0x022A, 0x823B,
                                   0x023E, 0x0234, 0x8231, 0x8213, 0x0216, 0x021C, 0x8219, 0x0208,
                                   0x820D, 0x8207, 0x0202};

  for (j = 0; j < data_blk_size; j++)
  {
    i = ((unsigned short)(crc_accum >> 8) ^ data_blk_ptr[j]) & 0xFF;
    crc_accum = (crc_accum << 8) ^ crc_table[i];
  }
  return crc_accum;
}

uint8_t write_dynamixel_v2(uint8_t id, uint16_t addr, uint8_t size, uint32_t data)
{
  uint8_t h1 = 0xFF, h2 = 0xFF, h3 = 0xFD, rsv = 0x00, cmd_write = 0x03;
  uint16_t len = 1 + 2 + size + 2;
  uint8_t sendbyte[20], receivebyte[20];
  memset(sendbyte, 0, sizeof(sendbyte));
  memset(receivebyte, 0, sizeof(receivebyte));
  sendbyte[0] = h1;
  sendbyte[1] = h2;
  sendbyte[2] = h3;
  sendbyte[3] = rsv;
  sendbyte[4] = id;
  sendbyte[5] = len & 0xFF;
  sendbyte[6] = (len >> 8) & 0xFF;
  sendbyte[7] = cmd_write;
  sendbyte[8] = addr & 0xFF;
  sendbyte[9] = (addr >> 8) & 0xFF;
  for (uint8_t i = 0; i < size; i++)
  {
    sendbyte[10 + i] = (data >> (8 * i)) & 0xFF;
  }
  uint16_t dt_crc = update_crc(0, sendbyte, 10 + size);
  sendbyte[10 + size] = dt_crc & 0xFF;
  sendbyte[11 + size] = (dt_crc >> 8) & 0xFF;
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, 1);
  HAL_UART_Transmit(&huart4, sendbyte, 10 + size + 2, 1000);
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, 0);
  HAL_UART_Receive(&huart4, receivebyte, 20, 10);
  return receivebyte[9];
}

uint32_t read_dynamixel_v2(uint8_t id, uint16_t addr, uint16_t size)
{
  uint8_t h1 = 0xFF, h2 = 0xFF, h3 = 0xFD, rsv = 0x00, cmd_read = 0x02;
  uint16_t len = 1 + 2 + 2 + 2;
  uint8_t sendbyte[20], receivebyte[20];
  memset(sendbyte, 0, sizeof(sendbyte));
  memset(receivebyte, 0, sizeof(receivebyte));
  uint32_t readValue = 0;
  sendbyte[0] = h1;
  sendbyte[1] = h2;
  sendbyte[2] = h3;
  sendbyte[3] = rsv;
  sendbyte[4] = id;
  sendbyte[5] = len & 0xFF;
  sendbyte[6] = (len >> 8) & 0xFF;
  sendbyte[7] = cmd_read;
  sendbyte[8] = addr & 0xFF;
  sendbyte[9] = (addr >> 8) & 0xFF;
  sendbyte[10] = size & 0xFF;
  sendbyte[11] = (size >> 8) & 0xFF;
  uint16_t dt_crc = update_crc(0, sendbyte, 12);
  sendbyte[12] = dt_crc & 0xFF;
  sendbyte[13] = (dt_crc >> 8) & 0xFF;
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, 1);
  HAL_UART_Transmit(&huart4, sendbyte, 14, 1000);
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, 0);
  HAL_UART_Receive(&huart4, receivebyte, 20, 10);
  if (receivebyte[1] == h1 && receivebyte[2] == h2 && receivebyte[3] == h3 && receivebyte[4] == rsv && receivebyte[5] == id && receivebyte[9] == 0x00)
  {
    for (uint8_t i = 0; i < size; i++)
    {
      readValue |= receivebyte[10 + i] << 8 * i;
    }
  }
  else
  {
    readValue = 0;
  }
  return readValue;
}

uint8_t getID_dynamixel_v2()
{
  uint8_t h1 = 0xFF, h2 = 0xFF, h3 = 0xFD, rsv = 0x00, id = 0xFE, cmd_ping = 0x01;
  uint16_t len = 1 + 2;
  uint8_t sendbyte[20], receivebyte[20];
  memset(sendbyte, 0, sizeof(sendbyte));
  memset(receivebyte, 0, sizeof(receivebyte));
  sendbyte[0] = h1;
  sendbyte[1] = h2;
  sendbyte[2] = h3;
  sendbyte[3] = rsv;
  sendbyte[4] = id;
  sendbyte[5] = len & 0xFF;
  sendbyte[6] = (len >> 8) & 0xFF;
  sendbyte[7] = cmd_ping;
  uint16_t dt_crc = update_crc(0, sendbyte, 8);
  sendbyte[8] = dt_crc & 0xFF;
  sendbyte[9] = (dt_crc >> 8) & 0xFF;
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, 1);
  HAL_UART_Transmit(&huart4, sendbyte, 10, 1000);
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, 0);
  HAL_UART_Receive(&huart4, receivebyte, 20, 10);
  if (receivebyte[1] == h1 && receivebyte[2] == h2 && receivebyte[3] == h3 && receivebyte[4] == rsv && receivebyte[9] == 0x00)
  {
    return receivebyte[5];
  }
  else
  {
    return 0x00;
  }
}

uint8_t reset_dynamixel_v2(uint8_t id)
{
  uint8_t h1 = 0xFF, h2 = 0xFF, h3 = 0xFD, rsv = 0x00, cmd_reset = 0x06;
  uint16_t len = 0x04;
  uint8_t sendbyte[20], receivebyte[20];
  memset(sendbyte, 0, sizeof(sendbyte));
  memset(receivebyte, 0, sizeof(receivebyte));
  sendbyte[0] = h1;
  sendbyte[1] = h2;
  sendbyte[2] = h3;
  sendbyte[3] = rsv;
  sendbyte[4] = id;
  sendbyte[5] = len & 0xFF;
  sendbyte[6] = (len >> 8) & 0xFF;
  sendbyte[7] = cmd_reset;
  sendbyte[8] = 0x02;
  uint16_t dt_crc = update_crc(0, sendbyte, 9);
  sendbyte[9] = dt_crc & 0xFF;
  sendbyte[10] = (dt_crc >> 8) & 0xFF;
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, 1);
  HAL_UART_Transmit(&huart4, sendbyte, 11, 1000);
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, 0);
  HAL_UART_Receive(&huart4, receivebyte, 20, 10);
  return receivebyte[9];
}

//uint8_t write_dynamixel_v1(uint8_t id, uint8_t addr, uint8_t size, uint16_t data)
//{
//  uint8_t h1 = 0xFF, h2 = 0xFF, cmd_write = 0x03;
//  uint8_t len = 1 + 1 + size + 1;
//  uint8_t sendbyte[20], receivebyte[20];
//  uint8_t crc_dataValue = 0;
//  memset(sendbyte, 0, sizeof(sendbyte));
//  memset(receivebyte, 0, sizeof(receivebyte));
//  sendbyte[0] = h1;
//  sendbyte[1] = h2;
//  sendbyte[2] = id;
//  sendbyte[3] = len;
//  sendbyte[4] = cmd_write;
//  sendbyte[5] = addr;
//  for (uint8_t i = 0; i < size; i++)
//  {
//    sendbyte[6 + i] = (data >> (8 * i)) & 0xFF;
//    crc_dataValue += (data >> (8 * i)) & 0xFF;
//  }
//  uint16_t dt_crc = ~(id + len + cmd_write + addr + crc_dataValue);
//  sendbyte[6 + size] = dt_crc;
//  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, 1);
//  HAL_UART_Transmit(&huart4, sendbyte, 6 + size + 1, 1000);
//  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, 0);
//  HAL_UART_Receive(&huart4, receivebyte, 20, 10);
//  return receivebyte[5];
//}

//uint16_t read_dynamixel_v1(uint8_t id, uint8_t addr, uint8_t size)
//{
//  uint8_t h1 = 0xFF, h2 = 0xFF, cmd_read = 0x02;
//  uint8_t len = 4;
//  uint8_t sendbyte[20], receivebyte[20];
//  memset(sendbyte, 0, sizeof(sendbyte));
//  memset(receivebyte, 0, sizeof(receivebyte));
//  uint16_t readValue = 0;
//  sendbyte[0] = h1;
//  sendbyte[1] = h2;
//  sendbyte[2] = id;
//  sendbyte[3] = len;
//  sendbyte[4] = cmd_read;
//  sendbyte[5] = addr;
//  sendbyte[6] = size;
//  uint16_t dt_crc = ~(id + len + cmd_read + addr + size);
//  sendbyte[7] = dt_crc;
//  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, 1);
//  HAL_UART_Transmit(&huart4, sendbyte, 8, 1000);
//  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, 0);
//  HAL_UART_Receive(&huart4, receivebyte, 20, 10);
//  if (receivebyte[1] == h1 && receivebyte[2] == h2 && receivebyte[3] == id && receivebyte[5] == 0x00)
//  {
//    for (uint8_t i = 0; i < size; i++)
//    {
//      readValue |= receivebyte[6 + i] << 8 * i;
//    }
//  }
//  else
//  {
//    readValue = 0;
//  }
//  return readValue;
//}

//uint8_t getID_dynamixel_v1()
//{
//  uint8_t h1 = 0xFF, h2 = 0xFF, id = 0xFE, cmd_ping = 0x01;
//  uint8_t len = 2;
//  uint8_t sendbyte[20], receivebyte[20];
//  memset(sendbyte, 0, sizeof(sendbyte));
//  memset(receivebyte, 0, sizeof(receivebyte));
//  sendbyte[0] = h1;
//  sendbyte[1] = h2;
//  sendbyte[2] = id;
//  sendbyte[3] = len;
//  sendbyte[4] = cmd_ping;
//  uint8_t dt_crc = ~(id + len + cmd_ping);
//  sendbyte[5] = dt_crc;
//  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, 1);
//  HAL_UART_Transmit(&huart4, sendbyte, 6, 1000);
//  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, 0);
//  HAL_UART_Receive(&huart4, receivebyte, 20, 10);
//  if (receivebyte[1] == h1 && receivebyte[2] == h2 && receivebyte[5] == 0x00)
//  {
//    return receivebyte[3];
//  }
//  else
//  {
//    return 0x00;
//  }
//}

void set_motor_pos_v2(uint8_t id, float pos_flt)
{
  uint32_t pos = pos_flt / (0.087912088);
  write_dynamixel_v2(id, 64, 1, 1);    // torque enable
  write_dynamixel_v2(id, 116, 4, pos); // position
}

void set_motor_id_v2(uint8_t id, uint8_t id_des)
{
  write_dynamixel_v2(id, 7, 1, id_des);
}

void set_motor_baudrate_v2(uint8_t id, uint8_t baudlevel)
{
  write_dynamixel_v2(id, 8, 1, baudlevel);
}

//void set_motor_pos_v1(uint8_t id, float pos_flt)
//{
//  uint16_t pos = pos_flt / (0.087912088);
//  write_dynamixel_v1(id, 24, 1, 1);   // torque enable
//  write_dynamixel_v1(id, 30, 2, pos); // position
//}

//void set_motor_id_v1(uint8_t id, uint8_t id_des)
//{
//  write_dynamixel_v1(id, 3, 1, id_des);
//}

//void set_motor_baudrate_v1(uint8_t id, uint8_t baudlevel)
//{
//  write_dynamixel_v1(id, 4, 1, baudlevel);
//}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_UART4_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_CRC_Init();
  MX_TIM5_Init();
  MX_TIM1_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_PWM_Start(&htim5, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim5, TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(&htim5, TIM_CHANNEL_3);
  HAL_TIM_PWM_Start(&htim5, TIM_CHANNEL_4);

  HAL_TIM_Base_Start_IT(&htim5);
  HAL_TIM_Base_Start(&htim5);
  HAL_TIM_Base_Start(&htim1);

  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_2);

  HAL_TIM_IC_Start_IT(&htim3, TIM_CHANNEL_1);
  HAL_TIM_IC_Start(&htim3, TIM_CHANNEL_2);
  HAL_TIM_IC_Start_IT(&htim2, TIM_CHANNEL_1);
  HAL_TIM_IC_Start(&htim2, TIM_CHANNEL_2);

  //Initial Value
//  Gripper(180, 180, 180, 0);
//  set_motor_pos_v2(1, 180);
//  set_motor_pos_v2(2, 225);

  STEPPER_POS(176.16);
  HAL_Delay(1000);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
while (1){
//	Gripper(180, 180, 180, 0);

//	set_motor_pos_v2(2, 225);
//	set_motor_pos_v2(1, 180);
//	  for (int sudut=125; sudut<=235;sudut++){
//		  set_motor_pos_v2(1, sudut); //servo 1 pos 125-235
//		  HAL_Delay(50);
//	  }
//	  for (int sudut=270; sudut>=180;sudut--){
//		  set_motor_pos_v2(2, sudut); //servo 2 pos 180-270
//		  HAL_Delay(50);
//	  }
//	  for (int sudut=235; sudut>=125;sudut--){
//		  set_motor_pos_v2(1, sudut); //servo 1 pos 125-235
//		  HAL_Delay(50);
//	  }
//	  for (int sudut=180; sudut<=270;sudut++){
//		  set_motor_pos_v2(2, sudut); //servo 2 pos 180-270
//		  HAL_Delay(50);
//	  }

	STEPPER_POS(176.16);
	HAL_Delay(1000);
	STEPPER_POS(26.37);
	HAL_Delay(1000);

//	STEPPER_CONTROL(1, 1600); // (1 -> CW = naik, Steps -> 1600 = 1rev = 7.8mm)
//	HAL_Delay(1000);
//	STEPPER_CONTROL(0, 1600); // (0 -> CCW = turun, Steps -> 1600 = 1rev = 7.8mm)
//	HAL_Delay(1000);

//	// Check KST
//	KST1(90);
//	KST2(90);
//	HAL_Delay(1000);
//	KST1(95);
//	KST2(95);
//	HAL_Delay(1000);
//
//	//	Check Paralax
//	PRLX1(90, 3);
//	PRLX2(90, 3);
//	HAL_Delay(1000);
//	PRLX1(100, 3);
//	PRLX2(100, 3);
//	HAL_Delay(1000);

//  Default 	: Gripper(180, 180, 180, 0)
//  Range	: roll = 45-315; pitch = 90-270; yaw = 90-270; jaw = 0-20 (-20 - 40)
//	Gripper(180, 180, 180, 0);
//	HAL_Delay(1000);
//	Gripper(90, 180, 180, 0);
//	HAL_Delay(1000);
//	Gripper(180, 90, 180, 0);
//	HAL_Delay(1000);
//	Gripper(180, 180, 90, 0);
//	HAL_Delay(1000);
//	Gripper(180, 180, 180, 30);
//	HAL_Delay(1000);


    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 3;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief CRC Initialization Function
  * @param None
  * @retval None
  */
static void MX_CRC_Init(void)
{

  /* USER CODE BEGIN CRC_Init 0 */

  /* USER CODE END CRC_Init 0 */

  /* USER CODE BEGIN CRC_Init 1 */

  /* USER CODE END CRC_Init 1 */
  hcrc.Instance = CRC;
  if (HAL_CRC_Init(&hcrc) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CRC_Init 2 */

  /* USER CODE END CRC_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 84-1;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 0xffff-1;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_SlaveConfigTypeDef sSlaveConfig = {0};
  TIM_IC_InitTypeDef sConfigIC = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 1000-1;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 4294967295;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_IC_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sSlaveConfig.SlaveMode = TIM_SLAVEMODE_RESET;
  sSlaveConfig.InputTrigger = TIM_TS_TI1FP1;
  sSlaveConfig.TriggerPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
  sSlaveConfig.TriggerPrescaler = TIM_ICPSC_DIV1;
  sSlaveConfig.TriggerFilter = 0;
  if (HAL_TIM_SlaveConfigSynchro(&htim2, &sSlaveConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 0;
  if (HAL_TIM_IC_ConfigChannel(&htim2, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_FALLING;
  sConfigIC.ICSelection = TIM_ICSELECTION_INDIRECTTI;
  if (HAL_TIM_IC_ConfigChannel(&htim2, &sConfigIC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_SlaveConfigTypeDef sSlaveConfig = {0};
  TIM_IC_InitTypeDef sConfigIC = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 1000-1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_IC_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sSlaveConfig.SlaveMode = TIM_SLAVEMODE_RESET;
  sSlaveConfig.InputTrigger = TIM_TS_TI1FP1;
  sSlaveConfig.TriggerPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
  sSlaveConfig.TriggerPrescaler = TIM_ICPSC_DIV1;
  sSlaveConfig.TriggerFilter = 0;
  if (HAL_TIM_SlaveConfigSynchro(&htim3, &sSlaveConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 0;
  if (HAL_TIM_IC_ConfigChannel(&htim3, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_FALLING;
  sConfigIC.ICSelection = TIM_ICSELECTION_INDIRECTTI;
  if (HAL_TIM_IC_ConfigChannel(&htim3, &sConfigIC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 84-1;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 20000;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */
  HAL_TIM_MspPostInit(&htim4);

}

/**
  * @brief TIM5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM5_Init(void)
{

  /* USER CODE BEGIN TIM5_Init 0 */

  /* USER CODE END TIM5_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM5_Init 1 */

  /* USER CODE END TIM5_Init 1 */
  htim5.Instance = TIM5;
  htim5.Init.Prescaler = 18-1;
  htim5.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim5.Init.Period = 14000;
  htim5.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim5.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim5) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim5, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim5) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim5, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim5, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim5, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM5_Init 2 */

  /* USER CODE END TIM5_Init 2 */
  HAL_TIM_MspPostInit(&htim5);

}

/**
  * @brief UART4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART4_Init(void)
{

  /* USER CODE BEGIN UART4_Init 0 */

  /* USER CODE END UART4_Init 0 */

  /* USER CODE BEGIN UART4_Init 1 */

  /* USER CODE END UART4_Init 1 */
  huart4.Instance = UART4;
  huart4.Init.BaudRate = 1000000;
  huart4.Init.WordLength = UART_WORDLENGTH_8B;
  huart4.Init.StopBits = UART_STOPBITS_1;
  huart4.Init.Parity = UART_PARITY_NONE;
  huart4.Init.Mode = UART_MODE_TX_RX;
  huart4.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart4.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART4_Init 2 */

  /* USER CODE END UART4_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOF, GPIO_PIN_9|GPIO_PIN_10, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);

  /*Configure GPIO pins : PE3 PE4 */
  GPIO_InitStruct.Pin = GPIO_PIN_3|GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pins : PF9 PF10 */
  GPIO_InitStruct.Pin = GPIO_PIN_9|GPIO_PIN_10;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

  /*Configure GPIO pin : PA4 */
  GPIO_InitStruct.Pin = GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
